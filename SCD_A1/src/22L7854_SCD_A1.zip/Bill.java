import java.util.Date;

public class Bill {
    private Customer customer;
    private Date billDate;
    private float regularMeterReading;
    private float peakMeterReading;
    private Date readingEntryDate;
    private float electricityCost;
    private float salesTaxAmount;
    private float fixedCharges;
    private float totalAmount;
    private Date dueDate;
    private Boolean isPaid;
    private Date paidDate;

}
